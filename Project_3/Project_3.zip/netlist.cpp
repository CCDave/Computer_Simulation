#include <ctype.h>
#include <iostream>
#include <fstream>
#include <string>
#include <list>
#include <iterator>
#include <sstream>
#include <assert.h>
#include "tokens.h"
#include "statements.h"
#include "netlist.h"


///////////NET///////////
void net::append_pin(pin *p) {
	connections_.push_back(p);
}

//////////////////////////

///////////PIN///////////
bool pin::create(gate *g, size_t pin_index, const evl_pin &p, const std::map<std::string, net *> &netlist_nets) {
	//store g and pin_index?????????????????? //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!IMplements This
	
	//pins_.push_back(g)
	
	std::string net_name = p.pin_name;
	if (p.msb == -1) { //A 1-bit wire
		std::map<std::string, net *>::const_iterator net = netlist_nets.find(net_name);
		nets_.push_back(net->second);
		//net->second->append_pin(p);		//this does not work
	}
	else {	//a bus
		std::map<std::string, net *>::const_iterator net = netlist_nets.find(net_name);
		for (int i = p.msb; i >= p.lsb; ++i) {
			nets_.push_back(net->second);
		}
	}
	return false;
}

void pin::set_as_input() {
	value_ = 1;
}

void pin::set_as_output() {
	value_ = 0;
}

//net * pin::get_net() {
//	return nets_[pin_index];
//}

//////////////////////////


///////////GATE///////////

bool gate::create_pins(const evl_pins &pins, const std::map<std::string, net*> &netlist_nets) {
	size_t pin_index = 0;
	for (evl_pins::const_iterator p = pins.begin(); p != pins.end(); ++p){
		create_pin(*p,pin_index, netlist_nets);
		++pin_index;
	}
	return validate_structural_semantics();
}

bool gate::create_pin(const evl_pin &p, size_t pin_index, const std::map<std::string, net *> &netlist_nets) {
	pins_.push_back(new pin);
	return pins_.back()->create(this, pin_index, p, netlist_nets);
}

gate::~gate() {
	for (size_t i = 0; i < pins_.size(); ++i) {
		delete pins_[i];
	}
}

std::string gate::get_name() const{
	return gate::name_;
}
std::string gate::get_type() const {
	return gate::type_;
}

//////////////////////////

/////////NETLIST//////////
netlist::~netlist() {
	for (std::list<gate *>::const_iterator it = gates_.begin(); it != gates_.end(); ++it) {
		delete &it;
	}
	for (std::map<std::string, net *>::const_iterator it2 = nets_.begin(); it2 != nets_.end(); ++it2) {
		delete &it2->first;
		delete &it2->second;
	}
}

bool netlist::create(const evl_wires &wires, const evl_components &comps) {
	return create_nets(wires) && create_gates(comps);
}


std::string make_net_name(std::string wire_name, int i) {
	assert (i >= 0);
	std::ostringstream oss;
	oss << wire_name << "[" << i << "]";
	return oss.str();
}

bool netlist::create_nets(const evl_wires &wires) {
	for (evl_wires::const_iterator it = wires.begin(); it != wires.end(); ++it) {
		if (it->second == 1) {
			create_net(it->first);
		}
		else {
			for (int i = 0; i < it->second; ++i) {
				create_net(make_net_name(it->first,i));
			}
		}
	}
	return true;
}

void netlist::create_net(std::string net_name) {
	assert(nets_.find(net_name) == nets_.end());
	nets_[net_name] = new net;
}

bool netlist::create_gates(const evl_components &comps) {
	for (evl_components::const_iterator it = comps.begin(); it != comps.end(); ++it) {
		create_gate(*it);
	}
	return true;
}

//GATES_ is not storing type_ and name_
bool netlist::create_gate(const evl_component &c) {
	if (c.type == "and") {
		gates_.push_back(new and_gate(c.name));
	}
	else if (c.type == "or") {
		gates_.push_back(new or_gate(c.name));
	}
	else if (c.type == "xor") {
		gates_.push_back(new xor_gate(c.name));
	}
	

	else if (c.type == "not") {
		gate *g = new not_gate(c.name);
		gates_.push_back(g);
	}
	else if (c.type == "buf") {
		gate *g = new buffer(c.name);
		gates_.push_back(g);
	}
	else if (c.type == "dff") {
		gate *g = new flip_flop(c.name);
		gates_.push_back(g);
	}


	else if (c.type == "one") {
		gates_.push_back(new one(c.name));
	}
	else if (c.type == "zero") {
		gates_.push_back(new zero(c.name));
	}
	else if (c.type == "input") {
		gates_.push_back(new input(c.name));
	}
	else if (c.type == "output") {
		gates_.push_back(new output(c.name));
	}
	else {
		std::cerr << "Gate does not exist" << std::endl;
	}

	return gates_.back()->create_pins(c.comp_pins, nets_);
}

void netlist::save(std::string file_name) {
	std::ofstream output_file(file_name.c_str());
	if(!output_file) {
		std::cerr << "I can't write" << output_file << "." << std::endl;
	}
	display_netlist(output_file);
}

void netlist::display_netlist(std::ostream &out) {
	out << "This should do something" << std::endl;		//Implment

	gates_.back();

	out << nets_.size() << " " << gates_.size() << std::endl;
	for (std::map<std::string, net *>::const_iterator net_it = nets_.begin(); net_it != nets_.end(); ++net_it) {
		out << "net " << net_it->first << " " << " something" << std::endl;		//not sure about connections_.size()
		
		out << "pin " << &gate::get_type << " " << &gate::get_name << std::endl;
	}

}

//////////////////////////


///////////GATES//////////

bool and_gate::validate_structural_semantics() {
	if (pins_.size() < 3)
		return false;
	pins_[0]->set_as_output();
	for (size_t i = 1; i < pins_.size(); ++i) {
		pins_[i]->set_as_input();
	}
	return true;
}
/*
void and_gate::compute_next_state() {
	net *input_net = pins_[1]->get_net();
	next_state_ = input_net->retrieve_logic_value();
}
*/
bool or_gate::validate_structural_semantics() {
	if (pins_.size() < 3)
		return false;
	pins_[0]->set_as_output();
	for (size_t i = 1; i < pins_.size(); ++i) {
		pins_[i]->set_as_input();
	}
	return true;
}

bool xor_gate::validate_structural_semantics() {
	if (pins_.size() < 3)
		return false;
	pins_[0]->set_as_output();
	for (size_t i = 1; i < pins_.size(); ++i) {
		pins_[i]->set_as_input();
	}
	return true;
}

bool not_gate::validate_structural_semantics() {
	if (pins_.size() != 2) return false;
	pins_[0]->set_as_output();
	pins_[1]->set_as_input();
	return true;
}

bool buffer::validate_structural_semantics() {
	if (pins_.size() != 2) return false;
	pins_[0]->set_as_output();
	pins_[1]->set_as_input();
	return true;
}

bool flip_flop::validate_structural_semantics() {
	if (pins_.size() != 2) return false;
	pins_[0]->set_as_output();
	pins_[1]->set_as_input();
	return true;
}
/*
void flip_flop::compute_next_state() {
	net *input_net = pins_[1]->get_net();
	next_state_ = input_net->retrieve_logic_value();
}
*/

//Each of the below can have an arbitrary width
bool one::validate_structural_semantics() {
	if (pins_.size() < 1)
		return false;
	for (size_t i = 0; i < pins_.size(); ++i) {
		pins_[i]->set_as_output();
	}
	return true;
}
bool zero::validate_structural_semantics() {
	if (pins_.size() < 1)
		return false;
	for (size_t i = 0; i < pins_.size(); ++i) {
		pins_[i]->set_as_output();
	}
	return true;
}
bool input::validate_structural_semantics() {
	if (pins_.size() < 1)
		return false;
	for (size_t i = 0; i < pins_.size(); ++i) {
		pins_[i]->set_as_output();
	}
	return true;
}

bool output::validate_structural_semantics() {
	if (pins_.size() < 1)
		return false;
	for (size_t i = 0; i < pins_.size(); ++i) {
		pins_[i]->set_as_input();
	}
	return true;
}



